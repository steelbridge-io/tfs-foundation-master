<?php
/**
 * Created by PhpStorm.
 * User: chrisparsons
 * Date: 2019-02-27
 * Time: 10:55
 */

// CSS output for cutomizer CSS modifications
if( is_customize_preview() ) {

	function output()
	{
		echo '<style>';

		$fptopbgcolor_color 		= get_theme_mod('fp-top-widget-bg-color' );
		$fptoptxtcolor					= get_theme_mod('fp-top-widget-txt-color' );
		$fp_topcard_label_color	= get_theme_mod('fp-topcard-label-color' );
		$fp_topcard_bg_color		= get_theme_mod( 'fp-topcard-bg-color' );
		$fp_topcard_txt_color 	= get_theme_mod( 'fp-topcard-txt-color' );
		$fp_bottomcard_img			= get_theme_mod('fp-bottomcard-img' );

		echo '#top-cta {
						background-color: ' . $fptopbgcolor_color . ';
						}' .
					'#top-cta, #top-cta h2, #top-cta p {
						color: ' . $fptoptxtcolor . ';
						}' .
					 '#top-card, #top-card h4 {
						color: ' . $fp_topcard_label_color . ';
						}' .
					'#topcardid.card-section {
						background-color: ' . $fp_topcard_bg_color . ';
					}' .
					'#topcardid, #topcardid h2, #topcardid p {
					color: ' . $fp_topcard_txt_color . ';
					}' .
					'.bottomcard.card .card-divider::after {
						background: url('. $fp_bottomcard_img .') no-repeat center;
						background-size: cover;
						content: "";
						opacity: 0.5;
						top: 0;
						left: 0;
						bottom: 0;
						right: 0;
						position: absolute;
						z-index: 1;
    			}';

		echo '</style>';
	}

	add_action('wp_head', 'output');
}
