<?php
/**
 * The sidebar containing the main widget area
 *
 * @package FoundationPress
 * @since FoundationPress 1.0.0
 */

?>

<aside id="sidebar-right-sidebar" class="column small-12 medium-4">
	<?php dynamic_sidebar( 'sidebar-widgets' ); ?>
</aside>

